package reconcile.featureVector.clusterFeature;

import java.util.Map;

import reconcile.Constructor;
import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.properties.Property;
import reconcile.general.RuleResolvers;
import reconcile.structuredClassifiers.CorefChain;


/*
 * This feature is: C if one NP is a pronoun and the other NP is its antecedent according to a rule-based algorithm I
 * otherwise
 */

public class PairTypeOL
    extends NominalClusterFeature {

public PairTypeOL() {
  name = this.getClass().getSimpleName();
}

@Override
public String[] getValues()
{
  return IC;
}

@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  String type = Constructor.createClusterFeature("SemTypePair").getValue(c1, c2, doc, featVector);
  if (type.equals("lo")||type.equals("ol")) {
    return COMPATIBLE;
  }
  return INCOMPATIBLE;
}

}
