package reconcile.featureVector.clusterFeature;

import java.util.Map;

import reconcile.Constructor;
import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.properties.Property;
import reconcile.general.RuleResolvers;
import reconcile.structuredClassifiers.CorefChain;


/*
 * This feature is: C if one NP is a pronoun and the other NP is its antecedent according to a rule-based algorithm I
 * otherwise
 */

public class ProResolveRuleCl
    extends NominalClusterFeature {

public ProResolveRuleCl() {
  name = this.getClass().getSimpleName();
}

@Override
public String[] getValues()
{
  return new String[]{"R1","R2","R3","R4","R5","R6","R7","R8","NONE"};
}

@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  if (Constructor.createClusterFeature("ProResolveCl").getValue(c1, c2, doc, featVector).equals(COMPATIBLE)) {
    
    return c2.getProperty(Property.RULE_NUM)==null?"NONE":c2.getProperty(Property.RULE_NUM).toString();
  }
  return "NONE";
}

}
