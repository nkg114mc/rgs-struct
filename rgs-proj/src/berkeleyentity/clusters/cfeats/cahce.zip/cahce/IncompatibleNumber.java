package reconcile.featureVector.clusterFeature;

import java.util.Map;

import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.FeatureUtils.GenderEnum;
import reconcile.features.FeatureUtils.NumberEnum;
import reconcile.features.properties.Gender;
import reconcile.features.properties.Number;
import reconcile.structuredClassifiers.CorefChain;


/*
 * This feature is: C the two np's agree in gender I if they disagree NA if the gender information for either cannot be
 * determined
 */

public class IncompatibleNumber
    extends NominalClusterFeature {

public IncompatibleNumber() {
  name = this.getClass().getSimpleName();
}

@Override
public String[] getValues()
{
  return IC;
}

@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  return c1.isNumberIncompatible(c2)?COMPATIBLE:INCOMPATIBLE;
}


}
