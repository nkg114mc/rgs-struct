package reconcile.featureVector.clusterFeature;

import java.util.Map;

import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.featureVector.NumericClusterFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.FeatureUtils.AnimacyEnum;
import reconcile.features.FeatureUtils.GenderEnum;
import reconcile.features.FeatureUtils.NumberEnum;
import reconcile.features.properties.Animacy;
import reconcile.features.properties.Gender;
import reconcile.features.properties.Number;
import reconcile.general.Constants;
import reconcile.structuredClassifiers.CorefChain;


/*
 * This feature is: C the two np's agree in gender I if they disagree NA if the gender information for either cannot be
 * determined
 */

public class NormChainSize1
    extends NumericClusterFeature {

public NormChainSize1() {
  name = this.getClass().getSimpleName();
}

@Override
public boolean structuredOnly(){
  return true;
}
@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  double size = c1.getCes().size();
  return Double.toString(size/(double)doc.getAnnotationSet(Constants.NP).size());//Double.toString(Math.log(size));
}

}
