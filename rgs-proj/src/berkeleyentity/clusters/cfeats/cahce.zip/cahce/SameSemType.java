package reconcile.featureVector.clusterFeature;

import java.util.Map;

import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.FeatureUtils.GenderEnum;
import reconcile.features.FeatureUtils.NPSemTypeEnum;
import reconcile.features.FeatureUtils.NumberEnum;
import reconcile.features.properties.Gender;
import reconcile.features.properties.NPSemanticType;
import reconcile.features.properties.Number;
import reconcile.structuredClassifiers.CorefChain;


/*
 * This feature is: C the two np's agree in gender I if they disagree NA if the gender information for either cannot be
 * determined
 */

public class SameSemType
    extends NominalClusterFeature {

public SameSemType() {
  name = this.getClass().getSimpleName();
}

@Override
public String[] getValues()
{
  return IC;
}

@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  NPSemTypeEnum type1 = (NPSemTypeEnum) c1.getProperty(NPSemanticType.getInstance());
  NPSemTypeEnum type2 = (NPSemTypeEnum) c2.getProperty(NPSemanticType.getInstance());
  if (type1.equals(NPSemTypeEnum.UNKNOWN) || type1.equals(NPSemTypeEnum.AMBIGUOUS)|| type1.equals(NPSemTypeEnum.NOTPERSON)) return INCOMPATIBLE;
  if (type1.equals(type2)) return COMPATIBLE;
  return INCOMPATIBLE;
}


}
