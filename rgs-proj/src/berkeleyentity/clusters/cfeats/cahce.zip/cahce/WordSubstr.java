package reconcile.featureVector.clusterFeature;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;

import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.FeatureUtils.GenderEnum;
import reconcile.features.properties.Gender;
import reconcile.general.Utils;
import reconcile.structuredClassifiers.CorefChain;


/*
 * This feature is: C the two np's agree in gender I if they disagree NA if the gender information for either cannot be
 * determined
 */

public class WordSubstr
    extends NominalClusterFeature {

public WordSubstr() {
  name = this.getClass().getSimpleName();
}

@Override
public String[] getValues()
{
  return IC;
}

@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  HashSet<String> w1 = (HashSet<String>) c1.getProperty(CorefChain.WORDS);
  HashSet<String> w2 = (HashSet<String>) c2.getProperty(CorefChain.WORDS);
  if(w1==null||w2==null)
    return INCOMPATIBLE;
  return Utils.isAnySubset(w1.toArray(new String[0]), w2.toArray(new String[0]))?COMPATIBLE:INCOMPATIBLE;
}

}
