package reconcile.featureVector.clusterFeature;

import java.util.Map;

import reconcile.data.Annotation;
import reconcile.data.Document;
import reconcile.featureVector.ClusterFeature;
import reconcile.featureVector.Feature;
import reconcile.featureVector.NominalClusterFeature;
import reconcile.featureVector.NominalFeature;
import reconcile.features.FeatureUtils;
import reconcile.features.FeatureUtils.AnimacyEnum;
import reconcile.features.FeatureUtils.GenderEnum;
import reconcile.features.FeatureUtils.NumberEnum;
import reconcile.features.properties.Animacy;
import reconcile.features.properties.Gender;
import reconcile.features.properties.Number;
import reconcile.structuredClassifiers.CorefChain;

public class SameAnimacy
    extends NominalClusterFeature {

public SameAnimacy() {
  name = this.getClass().getSimpleName();
}

@Override
public String[] getValues()
{
  return IC;
}

@Override
public String produceValue(CorefChain c1, CorefChain c2, Document doc, Map<ClusterFeature, String> featVector)
{
  AnimacyEnum an1 = (AnimacyEnum) c1.getProperty(Animacy.getInstance());
  AnimacyEnum an2 = (AnimacyEnum) c2.getProperty(Animacy.getInstance());
  if (an1.equals(AnimacyEnum.UNKNOWN) || an1.equals(AnimacyEnum.AMBIGUOUS)) return INCOMPATIBLE;
  if (an1.equals(an2)) return COMPATIBLE;
  return INCOMPATIBLE;
}


}
