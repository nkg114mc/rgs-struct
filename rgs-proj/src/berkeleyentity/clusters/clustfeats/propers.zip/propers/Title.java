package edu.berkeley.nlp.entity.clusters.clustfeats;


public class Title extends Property {

	private static Property ref = null;

	public static Property getInstance()
	{
		if (ref == null) {
			ref = new Title();
		}
		return ref;
	}


	@Override
	public Object produceValue(Annotation np, Document doc)
	{
		Boolean value;
		String s = doc.getAnnotText(np);
		value = FeatureUtils.getTitles().contains(s.toLowerCase()) && FeatureUtils.isCapitalized(s);
		return value;

	}

}
