package edu.berkeley.nlp.entity.clusters.clustfeats;

import edu.berkeley.nlp.entity.coref.DocumentGraph;
import edu.berkeley.nlp.entity.coref.Mention;

public class EmptyProperty extends Property {

	public EmptyProperty(String name) {
		this.name = name;
	}

	@Override
	public Object produceValue(Mention np, DocumentGraph doc)
	{
		return null;// np.getProperty(this);
	}

}
