package edu.berkeley.nlp.entity.clusters.clustfeats;

import java.util.ArrayList;

import edu.berkeley.nlp.entity.coref.DocumentGraph;
import edu.berkeley.nlp.entity.coref.Mention;

public class Words extends Property {

	private static Property ref = null;
	public static Property getInstance()
	{
		if (ref == null) {
			ref = new Words();
		}
		return ref;
	}

	@Override
	protected Object produceValue(Mention np, DocumentGraph docGraph) {
		String[] words = doc.getWords(np);
		return words;
	}

}
