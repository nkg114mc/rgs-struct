package edu.berkeley.nlp.entity.clusters.clustfeats;

import edu.berkeley.nlp.entity.coref.DocumentGraph;
import edu.berkeley.nlp.entity.coref.Mention;

/*
 * A simple class used to save some attributes of properties of single nps
 */
public abstract class Property {

	String name;

	public Property() {
		this.name = getClass().getSimpleName();
	}

	abstract protected Object produceValue(Mention np, DocumentGraph docGraph);


	public String toString() {
		return name;
	}

	public static final Property AUTHOR = new EmptyProperty("Author");
	public static final Property MATCHED_CE = new EmptyProperty("matched_ce");
	public static final Property HEAD_POS = new EmptyProperty("head_pos");
	public static final Property PRO_ANTES = new EmptyProperty("pro_antes");
	public static final Property RULE_NUM = new EmptyProperty("rule_num");
	public static final Property RULE_COREF_ID = new EmptyProperty("rule_coref_id");
	public static final Property PREDNOM = new EmptyProperty("prednom");
	public static final Property APPOSITIVE = new EmptyProperty("appositive");
	public static final Property DATE = new EmptyProperty("DATE");
	public static final Property LINKED_PROPER_NAME = new EmptyProperty("LinkedPN");
	public static final Property COMP_AUTHOR = new EmptyProperty("CAuthor");
	public static final Property GOLD_CATEGORY = new EmptyProperty("GoldCategory");

}
