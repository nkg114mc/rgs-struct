package edu.berkeley.nlp.entity.clusters.clustfeats;


import edu.berkeley.nlp.entity.coref.DocumentGraph;
import edu.berkeley.nlp.entity.coref.Mention;

public class AllGramRole
extends Property {

	private static Property ref = null;

	public static Property getInstance()
	{
		if (ref == null) {
			ref = new AllGramRole();
		}
		return ref;
	}


	@Override
	public Object produceValue(Mention np, DocumentGraph docGraph) {
		String value;
		Annotation hn = HeadNoun.getValue(np, doc);
		AnnotationSet dep = doc.getAnnotationSet(Constants.DEP).getContained(hn);
		value = "NONE";
		if (dep != null && dep.size() > 0) {
			value = dep.getFirst().getType();
		}
		return value;
	}

}
