package edu.berkeley.nlp.entity.randsearch.corefmetrics;

public class MucAcc {

}
